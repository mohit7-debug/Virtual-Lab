const experiments = [
  {
    id: "ohms-law", title: "Ohm's Law", icon: "⚡", subject: "Physics",
    description: "Explore the relationship between voltage, current and resistance.",
    instructions: ["Read the basic concept of Ohm's Law.", "Choose a voltage and resistance value.", "Run the simulation and observe the calculated current."],
    simulate: () => "Example: At 10 V and 5 Ω, current = 10 ÷ 5 = 2 A."
  },
  {
    id: "plant-cell", title: "Plant Cell Study", icon: "🌱", subject: "Biology",
    description: "Learn about the main parts of a plant cell and their functions.",
    instructions: ["Review the parts of a plant cell.", "Identify the cell wall, nucleus and chloroplast.", "Run the activity to review their functions."],
    simulate: () => "Observation: Chloroplasts contain chlorophyll and help plants perform photosynthesis."
  },
  {
    id: "acid-base", title: "Acid and Base", icon: "🧪", subject: "Chemistry",
    description: "Understand how indicators can help identify acids and bases.",
    instructions: ["Learn what acids and bases are.", "Select an indicator in a real supervised laboratory activity.", "Review the expected colour-change concept."],
    simulate: () => "Learning result: Litmus is a common indicator. Acids turn blue litmus red; bases turn red litmus blue."
  }
];

let selectedExperiment = null;
const completed = new Set();

const grid = document.getElementById("experimentGrid");
const labPanel = document.getElementById("labPanel");

function renderExperiments(items) {
  grid.innerHTML = "";
  items.forEach(exp => {
    const card = document.createElement("article");
    card.className = "experiment-card";
    const icon = document.createElement("div"); icon.className = "experiment-icon"; icon.textContent = exp.icon;
    const subject = document.createElement("p"); subject.textContent = exp.subject;
    const title = document.createElement("h3"); title.textContent = exp.title;
    const desc = document.createElement("p"); desc.textContent = exp.description;
    const button = document.createElement("button"); button.textContent = completed.has(exp.id) ? "Review experiment" : "Open experiment";
    button.addEventListener("click", () => openExperiment(exp.id));
    card.append(icon, subject, title, desc, button);
    grid.appendChild(card);
  });
}
function openExperiment(id) {
  selectedExperiment = experiments.find(e => e.id === id);
  document.getElementById("labTitle").textContent = selectedExperiment.title;
  document.getElementById("labDescription").textContent = selectedExperiment.description;
  const list = document.getElementById("labInstructions");
  list.innerHTML = "";
  selectedExperiment.instructions.forEach(step => {
    const li = document.createElement("li"); li.textContent = step; list.appendChild(li);
  });
  document.getElementById("simulationText").textContent = "Press Run simulation to view a learning example.";
  document.getElementById("simulationResult").textContent = "";
  labPanel.hidden = false;
  labPanel.scrollIntoView({behavior:"smooth", block:"start"});
}
function updateProgress() {
  const count = completed.size;
  const percent = Math.round(count / experiments.length * 100);
  document.getElementById("doneCount").textContent = count;
  document.getElementById("progressPercent").textContent = percent + "%";
  document.getElementById("progressBar").style.width = percent + "%";
  document.getElementById("progressMessage").textContent =
    count === experiments.length ? "Great work! You completed all available experiments." :
    `${count} of ${experiments.length} experiments completed. Keep learning!`;
}
document.getElementById("runSimulation").addEventListener("click", () => {
  if (selectedExperiment) document.getElementById("simulationResult").textContent = selectedExperiment.simulate();
});
document.getElementById("markComplete").addEventListener("click", () => {
  if (!selectedExperiment) return;
  completed.add(selectedExperiment.id);
  updateProgress();
  renderExperiments(experiments.filter(e => e.title.toLowerCase().includes(document.getElementById("searchInput").value.toLowerCase())));
  document.getElementById("simulationResult").textContent = "Experiment marked as completed.";
});
document.getElementById("closeLab").addEventListener("click", () => { labPanel.hidden = true; });
document.getElementById("searchInput").addEventListener("input", event => {
  const query = event.target.value.toLowerCase();
  renderExperiments(experiments.filter(e => `${e.title} ${e.subject}`.toLowerCase().includes(query)));
});
document.getElementById("totalCount").textContent = experiments.length;
renderExperiments(experiments);
updateProgress();
