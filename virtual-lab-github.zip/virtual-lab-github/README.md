# Virtual Lab

A beginner-friendly Virtual Lab website built with HTML, CSS and JavaScript.

## Features
- Student dashboard
- Experiment selection and search
- Instructions for each experiment
- Simple learning simulations
- Completion tracking and progress bar

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a web browser.

## Publish with GitHub Pages
1. Create a GitHub repository named `virtual-lab`.
2. Upload `index.html`, the `css` folder, the `js` folder and this README.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The published URL will appear in the Pages section.

## Note
This is an educational demonstration. The simulations are simplified learning examples, not substitutes for supervised physical laboratory work.
